<?php
    require_once 'PHPMailerAutoload.php';
    $mail = new PHPMailer();
    $mail ->isSMTP();
//    $mail -> SMTPOptions = array(
//        'ssl' => array(
//            'verify_peer' => false,
//            'verify_peer_name' => false,
//            'allow_self_signed' => true
//        )
//    );
    $mail -> SMTPDebug = 2;
    $mail -> Host = "smtp.gmail.com";
    $mail -> SMTPSecure = "tls";
    $mail -> Port = 587;
    $mail -> SMTPAuth = true;
    $mail -> Username = 'ramonbarbosa123456789@gmail.com';
    $mail -> Password = 'zyjumxzaoirorqhd';
    $mail -> setFrom("ramonbarbosa123456789@gmail.com", "Ramon Teste");
    $mail -> addAddress("ramonbarbosa123456789@gmail.com");
    $mail -> Subject = "Email de teste";
    $mail -> Body = "este é o corpo da minha mensagem";
    
    if($mail->send()){
        echo "deu tudo certo";
    } else {
        echo "deu tudo errado";
    }

?>