<?php
    require_once("php/conexao.php");
    $query = mysqli_query($connection, "select * from");
?>