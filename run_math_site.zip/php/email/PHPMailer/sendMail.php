<?php
    if($_GET && isset($_GET['assunto']) && isset($_GET['para']) && isset($_GET['html']) ){
        $para = $GET['para'];
        $html = $GET['html'];
        $assunto = $GET['assunto'];
        
        require_once 'PHPMailerAutoload.php';
        $mail = new PHPMailer();
        $mail ->isSMTP();
        $mail -> SMTPDebug = 2;
        $mail -> Host = "smtp.gmail.com";
        $mail -> SMTPSecure = "tls";
        $mail -> Port = 587;
        $mail -> SMTPAuth = true;
        $mail -> Username = 'run.math.19@gmail.com';
        $mail -> Password = 'wlmucxyycytefbdc';
        $mail -> setFrom("run.math.19@gmail.com", "Run Math Suporte");
        $mail -> addAddress("$para");
        $mail -> Subject = "$assunto";

        $mail->msgHTML(file_get_contents('$html'), __DIR__);

        $mail->AltBody = 'Erro ao carregar mensagem :(';

        if($mail->send()){
            echo "deu tudo certo";
        } else {
            echo "deu tudo errado";
        }
    } else {
        echo "sem get";
    }
?>